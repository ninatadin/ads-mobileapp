package com.example.seminarski8;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "seminarski.db";
    private static final int DATABASE_VERSION = 1;


    private static final String TABLE_KORISNIK = "korisnik";
    private static final String COLUMN_KORISNIK_ID = "id";
    private static final String COLUMN_KORISNIK_KORISNICKO_IME = "korisnicko_ime";
    private static final String COLUMN_KORISNIK_SIFRA = "sifra";


    private static final String TABLE_OGLAS = "oglas";
    private static final String COLUMN_OGLAS_ID = "id";
    private static final String COLUMN_OGLAS_NAZIV = "naziv";
    private static final String COLUMN_OGLAS_CENA = "cena";
    private static final String COLUMN_OGLAS_KORISNIK_ID = "korisnik_id";

    public DatabaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        String createKorisnikTable = "CREATE TABLE " + TABLE_KORISNIK + "("
                + COLUMN_KORISNIK_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_KORISNIK_KORISNICKO_IME + " TEXT,"
                + COLUMN_KORISNIK_SIFRA + " TEXT"
                + ")";
        sqLiteDatabase.execSQL(createKorisnikTable);

        String createOglasTable = "CREATE TABLE " + TABLE_OGLAS + "("
                + COLUMN_OGLAS_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_OGLAS_NAZIV + " TEXT,"
                + COLUMN_OGLAS_CENA + " REAL,"
                + COLUMN_OGLAS_KORISNIK_ID + " INTEGER,"
                + "FOREIGN KEY(" + COLUMN_OGLAS_KORISNIK_ID + ") REFERENCES " + TABLE_KORISNIK + "(" + COLUMN_KORISNIK_ID + ")"
                + ")";
        sqLiteDatabase.execSQL(createOglasTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {

        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_OGLAS);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_KORISNIK);


        onCreate(sqLiteDatabase);
    }

    void dodajKorisnika (String korisnickoime, String sifra) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_KORISNIK_KORISNICKO_IME, korisnickoime);
        cv.put(COLUMN_KORISNIK_SIFRA, sifra);
        long rezultat = db.insert(TABLE_KORISNIK, null,cv);

    }

    boolean login(String korisnickoime, String sifra)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM korisnik WHERE sifra = " + "'" + sifra + "'" + " AND korisnicko_ime = " + "'" + korisnickoime + "'", null);
        if(c.getCount() == 0)
        {
            return false;
        }
        else {
            return true;
        }

    }

    String vratiID(String korisnickoime, String sifra)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c = db.rawQuery("SELECT id FROM korisnik WHERE sifra = " + "'" + sifra + "'" + " AND korisnicko_ime = " + "'" + korisnickoime + "'", null);
        c.moveToFirst();
        return c.getString(0);
    }

    public void noviOglas(int id, String naziv, int cena) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_OGLAS_KORISNIK_ID, id);
        values.put(COLUMN_OGLAS_NAZIV, naziv);
        values.put(COLUMN_OGLAS_CENA, cena);

        db.insert(TABLE_OGLAS, null, values);

        db.close();
    }

    Cursor staviIme(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c = null;
        if(db != null){
            c = db.rawQuery("SELECT  korisnicko_ime, sifra FROM Korisnik where id= " + id  , null);
        }
        return c;
    }

    void obrisiKorisnika(int id){
        SQLiteDatabase db = this.getWritableDatabase();
        String command = "DELETE FROM korisnik WHERE id = " + id;
        db.execSQL(command);
        command = "DELETE FROM oglas WHERE korisnik_id = " + id;
        db.execSQL(command);

    }
    void upisiNovePodatke(String id, String ime, String sifra)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        String command = "UPDATE korisnik SET korisnicko_ime = " + "'" + ime + "'" + ", sifra = " +"'" + sifra + "'"  + " WHERE id = "   + id;
        db.execSQL(command);
    }

    Cursor vrati_moje_oglase(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c = null;
        if(db != null){
            c = db.rawQuery("select o.id,  o.naziv, o.cena from oglas o, korisnik k\n" +
                    "where o.korisnik_id=k.id and o.korisnik_id =  "+id , null);
        }
        return c;
    }

    void obrisiOglas (int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        String command = "DELETE FROM oglas WHERE id = " + id;
        db.execSQL(command);
    }

    Cursor vrati_oglase(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c = null;
        if(db != null){
            c = db.rawQuery("select k.korisnicko_ime,  o.naziv, o.cena from oglas o, korisnik k\n" +
                    "where o.korisnik_id=k.id and o.korisnik_id !=  "+id + " order by o.cena asc", null);
        }
        return c;
    }

    Cursor vrati_oglase_opadajuci(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c = null;
        if(db != null){
            c = db.rawQuery("select k.korisnicko_ime,  o.naziv, o.cena from oglas o, korisnik k\n" +
                    "where o.korisnik_id=k.id and o.korisnik_id !=  "+id + " order by o.cena desc", null);
        }
        return c;
    }

    Cursor pretraga(String id, String s) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c = null;
        if (db != null) {
            String query = "SELECT k.korisnicko_ime, o.naziv, o.cena FROM oglas o, korisnik k " +
                    "WHERE o.korisnik_id=k.id AND o.korisnik_id != ? AND o.naziv LIKE ? || '%' " +
                    "ORDER BY o.cena DESC";

            String[] selectionArgs = new String[]{id, s};
            c = db.rawQuery(query, selectionArgs);
        }
        return c;
    }

}
