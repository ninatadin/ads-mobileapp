package com.example.seminarski8;

import androidx.appcompat.app.AppCompatActivity;
import static com.example.seminarski8.MainActivity.id;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Izmena extends AppCompatActivity {
EditText Ime, sifra1, sifra2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_izmena);
        Ime = findViewById(R.id.Ime);
        sifra1 = findViewById(R.id.sifra);
        sifra2 = findViewById(R.id.sifra2);
        DatabaseHelper db= new DatabaseHelper(this);
        Cursor cursor = db.staviIme(Integer.parseInt(id));
        if(cursor.getCount() == 0){
            Toast.makeText(this,"No data",Toast.LENGTH_SHORT).show();
        }
        while (cursor.moveToNext()){
            Ime.setText(cursor.getString(0));
            sifra1.setText(cursor.getString(1));
            sifra2.setText(cursor.getString(1));
        }
    }
    public void obrisiKorisnika (View view) {
        DatabaseHelper baza = new DatabaseHelper(Izmena.this);
        baza.obrisiKorisnika(Integer.parseInt(id));
        Toast.makeText(this, "Korisnik je izbrisan", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        this.finish();
    }

    public void izmeniKorisnika (View view){
        String IME = Ime.getText().toString().trim();
        String SIFRA1 = sifra1.getText().toString().trim();
        String SIFRA2 = sifra2.getText().toString().trim();
        if(SIFRA1.equals(SIFRA2)){
            DatabaseHelper baza = new DatabaseHelper(Izmena.this);
            baza.upisiNovePodatke(id, IME, SIFRA1 );
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            this.finish();
        }
    }

    public void onBackPressed() {
        Intent intent = new Intent(this, Pocetna.class);
        startActivity(intent);
        this.finish();
    }

}