package com.example.seminarski8;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;

import androidx.core.view.WindowCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.seminarski8.databinding.ActivityMainBinding;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public static String id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ImageView myImageView = findViewById(R.id.myImageView);


    }
    public void Registracija (View view ) {
        Intent intent = new Intent(this, RegistracijaActivity.class);
        startActivity(intent);
        this.finish();
    }

    public void Prijava (View view){
        DatabaseHelper baza = new DatabaseHelper(MainActivity.this);
        EditText korisnickoime = findViewById(R.id.korisnickoime);
        EditText sifra = findViewById(R.id.sifra);
        String Korisnickoime = korisnickoime.getText().toString().trim();
        String Sifra = sifra.getText().toString().trim();
        if (baza.login(Korisnickoime, Sifra)){
            id=baza.vratiID(Korisnickoime, Sifra);
            Intent intent = new Intent(this, Pocetna.class);
            startActivity(intent);
            this.finish();
        }

    }


}