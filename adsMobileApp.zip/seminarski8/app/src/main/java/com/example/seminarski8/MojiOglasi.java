package com.example.seminarski8;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import static com.example.seminarski8.MainActivity.id;


import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.List;

public class MojiOglasi extends AppCompatActivity {
    RecyclerView recyclerView;
    OglasAdapter oglasAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_moji_oglasi);
        ImageView backgroundImageView = findViewById(R.id.backgroundImageViewS);
        backgroundImageView.setImageResource(R.drawable.slika);
        recyclerView = findViewById(R.id.recycler_view);
        DatabaseHelper db = new DatabaseHelper(this);
        Cursor c = db.vrati_moje_oglase(id);

        List<Oglas> oglasi = new ArrayList<>();

        if (c != null && c.moveToFirst()) {
            do {

                int oglasId = c.getInt(0);
                String naslov = c.getString(1);
                double cena = c.getDouble(2);



                Oglas oglas = new Oglas(oglasId, naslov, cena);
                oglasi.add(oglas);

            } while (c.moveToNext());
        }
        oglasAdapter = new OglasAdapter(this, oglasi);
        recyclerView.setAdapter(oglasAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(MojiOglasi.this));


    }
    public void onBackPressed() {
        Intent intent = new Intent(this, Pocetna.class);
        startActivity(intent);
        this.finish();
    }

}