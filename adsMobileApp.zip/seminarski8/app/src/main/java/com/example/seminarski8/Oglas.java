package com.example.seminarski8;

public class Oglas {
    private int id;
    private String naziv;
    private double cena;
    private String ime;

    public Oglas(int oglasId, String naslov, double cena) {
        id = oglasId;
        naziv = naslov;
        this.cena = cena;
    }
    public Oglas(String ime, String naslov, double cena) {
        this.ime = ime;
        naziv = naslov;
        this.cena = cena;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public double getCena() {
        return cena;
    }

    public void setCena(double cena) {
        this.cena = cena;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }
}
