package com.example.seminarski8;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class OglasAdapter extends RecyclerView.Adapter<OglasAdapter.OglasViewHolder> {
    private Context context;
    private List<Oglas> listaOglasa;

    public OglasAdapter(Context context, List<Oglas> listaOglasa) {
        this.context = context;
        this.listaOglasa = listaOglasa;
    }

    @NonNull
    @Override
    public OglasViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.my_row, parent, false);
        return new OglasViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OglasViewHolder holder, int position) {
        Oglas oglas = listaOglasa.get(holder.getAdapterPosition());
        holder.nazivTextView.setText(oglas.getNaziv());
        holder.cenaTextView.setText(String.valueOf(oglas.getCena()));

        holder.deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int oglasId = oglas.getId();
                DatabaseHelper db = new DatabaseHelper(v.getContext());
                db.obrisiOglas(oglasId);
                listaOglasa.remove(holder.getAdapterPosition());
                notifyItemRemoved(holder.getAdapterPosition());
            }
        });
    }

    @Override
    public int getItemCount() {
        return listaOglasa.size();
    }

    public class OglasViewHolder extends RecyclerView.ViewHolder {
        public TextView nazivTextView;
        public TextView cenaTextView;
        public Button deleteButton;

        public OglasViewHolder(@NonNull View itemView) {
            super(itemView);
            nazivTextView = itemView.findViewById(R.id.nazivUslugeTextView);
            cenaTextView = itemView.findViewById(R.id.cenaUslugeTextView);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }
}
