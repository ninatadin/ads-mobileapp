package com.example.seminarski8;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class OglasAdapter2 extends RecyclerView.Adapter<OglasAdapter2.OglasViewHolder> {
    private List<Oglas> listaOglasa;

    public OglasAdapter2(List<Oglas> listaOglasa) {
        this.listaOglasa = listaOglasa;
    }

    @NonNull
    @Override
    public OglasViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row, parent, false);
        return new OglasViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OglasViewHolder holder, int position) {
        Oglas oglas = listaOglasa.get(position);
        holder.imeTextView.setText(oglas.getIme());
        holder.nazivTextView.setText(oglas.getNaziv());
        holder.cenaTextView.setText(String.valueOf(oglas.getCena()));
    }

    @Override
    public int getItemCount() {
        return listaOglasa.size();
    }

    public static class OglasViewHolder extends RecyclerView.ViewHolder {
        public TextView imeTextView;
        public TextView nazivTextView;
        public TextView cenaTextView;

        public OglasViewHolder(View view) {
            super(view);
            imeTextView = view.findViewById(R.id.imeTextView);
            nazivTextView = view.findViewById(R.id.naslovTextView);
            cenaTextView = view.findViewById(R.id.cenaTextView);
        }
    }
}
