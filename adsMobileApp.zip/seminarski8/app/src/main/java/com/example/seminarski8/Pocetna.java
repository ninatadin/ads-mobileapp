package com.example.seminarski8;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.os.Bundle;
import android.widget.ImageView;

import static com.example.seminarski8.MainActivity.id;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class Pocetna extends AppCompatActivity {
    Button dugme;
    OglasAdapter2 oglasAdapter;
   RecyclerView recyclerView;
    private EditText etSearchBox;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pocetna);
        ImageView backgroundImageView = findViewById(R.id.backgroundImageView);
        backgroundImageView.setImageResource(R.drawable.slika);
        DatabaseHelper db = new DatabaseHelper (this);
        Cursor c = db.vrati_oglase(id);
        recyclerView = findViewById(R.id.recyclerView);
        List<Oglas> oglasi = new ArrayList<>();

        if (c != null && c.moveToFirst()) {
            do {

                String ime = c.getString(0);
                String naslov = c.getString(1);
                double cena = c.getDouble(2);



                Oglas oglas = new Oglas(ime, naslov, cena);
                oglasi.add(oglas);

            } while (c.moveToNext());
        }
        oglasAdapter = new OglasAdapter2(oglasi);
        recyclerView.setAdapter(oglasAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(Pocetna.this));
      dugme = (Button ) findViewById(R.id.button);
      dugme.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view) {
              Intent intent = new Intent (Pocetna.this, Izmena.class);
              startActivity(intent);
              finish();
          }
      });
        etSearchBox = findViewById(R.id.etSearchBox);
        etSearchBox.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                String searchQuery = charSequence.toString().trim();
                DatabaseHelper db = new DatabaseHelper(Pocetna.this);
                Cursor c = db.pretraga(id, searchQuery);
                recyclerView = findViewById(R.id.recyclerView);
                List<Oglas> oglasi = new ArrayList<>();

                if (c != null && c.moveToFirst()) {
                    do {

                        String ime = c.getString(0);
                        String naslov = c.getString(1);
                        double cena = c.getDouble(2);



                        Oglas oglas = new Oglas(ime, naslov, cena);
                        oglasi.add(oglas);

                    } while (c.moveToNext());
                }
                oglasAdapter = new OglasAdapter2(oglasi);
                recyclerView.setAdapter(oglasAdapter);
                recyclerView.setLayoutManager(new LinearLayoutManager(Pocetna.this));

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }


    public void Dodajoglas (View view) {
        Intent intent = new Intent(this, dodavanjeoglasa.class);
        startActivity(intent);
        this.finish();
    }
    public void onBackPressed() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        this.finish();
    }
    public void Prikazi(View view){
        Intent intent = new Intent (this, MojiOglasi.class) ;
        startActivity(intent);
        this.finish();
    }



    public void filter(View view){
        Button  dugme = findViewById(R.id.filter);
        String tekst = dugme.getText().toString().trim();
        if(tekst.equals("Rastuci")){
            dugme.setText("Opadajuci");
            recyclerView = findViewById(R.id.recyclerView);
            DatabaseHelper db = new DatabaseHelper(Pocetna.this);

            Cursor c = db.vrati_oglase_opadajuci(id);
            List<Oglas> oglasi = new ArrayList<>();

            if (c != null && c.moveToFirst()) {
                do {

                    String ime = c.getString(0);
                    String naslov = c.getString(1);
                    double cena = c.getDouble(2);



                    Oglas oglas = new Oglas(ime, naslov, cena);
                    oglasi.add(oglas);

                } while (c.moveToNext());
            }
            oglasAdapter = new OglasAdapter2(oglasi);
            recyclerView.setAdapter(oglasAdapter);
            recyclerView.setLayoutManager(new LinearLayoutManager(Pocetna.this));


        }else {
            dugme.setText("Rastuci");
            recyclerView = findViewById(R.id.recyclerView);
            DatabaseHelper db = new DatabaseHelper(Pocetna.this);

            Cursor c = db.vrati_oglase(id);
            List<Oglas> oglasi = new ArrayList<>();

            if (c != null && c.moveToFirst()) {
                do {

                    String ime = c.getString(0);
                    String naslov = c.getString(1);
                    double cena = c.getDouble(2);



                    Oglas oglas = new Oglas(ime, naslov, cena);
                    oglasi.add(oglas);

                } while (c.moveToNext());
            }
            oglasAdapter = new OglasAdapter2(oglasi);
            recyclerView.setAdapter(oglasAdapter);
            recyclerView.setLayoutManager(new LinearLayoutManager(Pocetna.this));
        }
    }

}

