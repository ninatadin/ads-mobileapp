package com.example.seminarski8;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class RegistracijaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registracija);


    }

    public void dodajKorisnika (View view) {
        EditText korisnickoime = findViewById(R.id.KorisnickoIme);
        EditText lozinka = findViewById(R.id.Lozinka);
        EditText ponovljenalozinka = findViewById(R.id.PonovljenaLozinka);

        String Korisnickoime = korisnickoime.getText().toString().trim();
        String Lozinka = lozinka.getText().toString().trim();
        String Ponovljenalozinka = ponovljenalozinka.getText().toString().trim();

        if(Lozinka.equals(Ponovljenalozinka)){
            DatabaseHelper baza = new DatabaseHelper(RegistracijaActivity.this);
            baza.dodajKorisnika(Korisnickoime, Lozinka );
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            this.finish();
        }
else {Toast.makeText(this, "Lozinka nije dobro uneta", Toast.LENGTH_SHORT).show();
            lozinka.getText().clear();
            ponovljenalozinka.getText().clear();}
    }

    public void onBackPressed() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        this.finish();
    }
}