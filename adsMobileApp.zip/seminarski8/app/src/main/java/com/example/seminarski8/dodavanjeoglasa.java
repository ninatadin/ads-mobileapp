package com.example.seminarski8;

import androidx.appcompat.app.AppCompatActivity;
import static com.example.seminarski8.MainActivity.id;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class dodavanjeoglasa extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodavanjeoglasa);
    }

    public void Unesioglas (View view) {
        EditText Naziv=findViewById(R.id.Naziv);
        EditText Cena=findViewById(R.id.Cena);
        String NAZIV = Naziv.getText().toString().trim();
        String CENA = Cena.getText().toString().trim();
        int cena;
        try {
            cena = Integer.parseInt(CENA);
        } catch (NumberFormatException e) {

            cena = 0;
        }
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        dbHelper.noviOglas(Integer.parseInt(id), NAZIV, cena);
        Toast.makeText(this, "Oglas je dodat.", Toast.LENGTH_SHORT).show();

    }

    public void onBackPressed() {
        Intent intent = new Intent(this, Pocetna.class);
        startActivity(intent);
        this.finish();
    }
}